# sisop-g1 

# Trabajo práctico de la materia Sistemas Operativos - FIUBA

## Integrantes

* **Burastero Maximiliano Ariel**
* **Galván Pedro Nahuel**
* **Perez Bustos Drew María Victoria**
* **Prado María Florencia**
* **Suppes Maximiliano**


## Descarga del paquete

Una explicación de cómo descargar el paquete

## Descompresión del paquete

Una explicación de cómo descomprimir, crear directorio del grupo, etc
listado de comandos

### Contenido del paquete

Una explicación de lo que se crea a partir de la descompresión

## Pre-requisitos

Una explicación sobre que se requiere para poder instalar y/o ejecutar el sistema 

* Perl versión 5 o superior


## Instalación

### Instrucciones

Instrucciones de instalación del sistema 
Una explicación de como se hace una instalación, listado de comandos

### Reparación de una instalación

Una explicacion de como reparar la reparación de la instalación, listado de comandos

### Contenido de la instalación

Que nos deja la instalación y dónde

## Ejecución

### Primeros pasos

Cuáles son los primeros pasos para poder ejecutar el sistema
Como arrancar o detener comandos 
Cualquier otra indicación, diagrama, cuadro que considere adecuada, por ejemplo

### Listador

Es invocado automáticamente por el "Validador" a través del comando:

```
perl listador.pl -a
```
O puede ser invocado manualmente ejecutando:

```
perl listador.pl -m
```

También se cuenta con la posibilidad de acceder a líneas de ayuda para el modo manual, agregando "-h en la llamada a la funcion:


```
perl listador.pl -m -h
```

